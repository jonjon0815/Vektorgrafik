Hallo Herr Krauter,
ich hatte in den Ferien coronabedingt etwas zu viel Freizeit, in der ich das Programm dann etwas über das
Skript hinaus programmiert habe. Hin und wieder weicht mein Programm vielleicht von der Lösung im Skript
ab, da es Teilweise so für andere Funktionen einfacher war.